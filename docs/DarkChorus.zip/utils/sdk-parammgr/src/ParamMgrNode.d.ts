import { ParamMgrNode } from './types';

export default ParamMgrNode;
