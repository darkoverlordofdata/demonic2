import { WamNode } from './types';

export default WamNode;
