declare const initializeWamGroup: (groupId: string, groupKey: string) => void;

export default initializeWamGroup;
