import { ParamMgrFactory } from './types';

export default ParamMgrFactory;
