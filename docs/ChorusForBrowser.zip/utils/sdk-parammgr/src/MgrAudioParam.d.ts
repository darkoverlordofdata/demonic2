import { MgrAudioParam } from './types';

export default MgrAudioParam;
