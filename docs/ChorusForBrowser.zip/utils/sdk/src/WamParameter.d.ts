import { WamParameter } from '@webaudiomodules/api';

declare const getWamParameter: (moduleId?: string) => typeof WamParameter;

export default getWamParameter;
