import { WebAudioModule } from './types';

export default WebAudioModule;
