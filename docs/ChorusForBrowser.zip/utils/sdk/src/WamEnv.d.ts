declare const initializeWamEnv: (apiVersion: string) => void;

export default initializeWamEnv;
